const allProfilesDTO = require('./allProfilesDTO');
const createProfileDTO = require('./createProfileDTO');
const updateProfileDTO = require('./updateProfileDTO');
const deleteProfileDTO = require('./deleteProfileDTO');
const findOneProfileDTO = require('./findOneProfileDTO');
module.exports = {
	allProfilesDTO,
	createProfileDTO,
	updateProfileDTO,
	deleteProfileDTO,
	findOneProfileDTO
};

const allRecommendationsDTO = require('./allRecommendationsDTO');
module.exports = {
  allRecommendationsDTO,
};

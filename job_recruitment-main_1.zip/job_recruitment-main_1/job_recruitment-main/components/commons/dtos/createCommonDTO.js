module.exports = ({ common: { _id, attributes } }) => ({
	id: _id,
	attributes
});

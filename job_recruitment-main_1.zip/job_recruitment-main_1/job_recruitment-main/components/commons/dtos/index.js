const allCommonsDTO = require('./allCommonsDTO');
const createCommonDTO = require('./createCommonDTO');
const updateCommonDTO = require('./updateCommonDTO');
const deleteCommonDTO = require('./deleteCommonDTO');
const findOneCommonDTO = require('./findOneCommonDTO');
module.exports = {
	allCommonsDTO,
	createCommonDTO,
	updateCommonDTO,
	deleteCommonDTO,
	findOneCommonDTO
};

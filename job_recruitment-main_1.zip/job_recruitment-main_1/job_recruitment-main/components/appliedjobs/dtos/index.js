const allAppliedjobsDTO = require('./allAppliedjobsDTO');
const createAppliedJobDTO = require('./createAppliedJobDTO');
const updateAppliedJobDTO = require('./updateAppliedJobDTO');
const deleteAppliedJobDTO = require('./deleteAppliedJobDTO');
const findOneAppliedJobDTO = require('./findOneAppliedJobDTO');
module.exports = {
	allAppliedjobsDTO,
	createAppliedJobDTO,
	updateAppliedJobDTO,
	deleteAppliedJobDTO,
	findOneAppliedJobDTO
};

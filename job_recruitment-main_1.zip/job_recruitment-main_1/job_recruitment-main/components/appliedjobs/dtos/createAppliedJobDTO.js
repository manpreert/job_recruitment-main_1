module.exports = ({ appliedjob: {} }) => ({
  status: 'ok',
  msg: 'Job was successfully applied',
});

const allSkillsDTO = require('./allSkillsDTO');
const createSkillDTO = require('./createSkillDTO');
const updateSkillDTO = require('./updateSkillDTO');
const deleteSkillDTO = require('./deleteSkillDTO');
const findOneSkillDTO = require('./findOneSkillDTO');
module.exports = {
	allSkillsDTO,
	createSkillDTO,
	updateSkillDTO,
	deleteSkillDTO,
	findOneSkillDTO
};

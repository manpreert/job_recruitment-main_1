module.exports = ({ shortlist: { job, users } }) => ({
  job,
  users,
});

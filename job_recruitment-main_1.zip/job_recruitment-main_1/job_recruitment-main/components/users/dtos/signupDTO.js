module.exports = ({ user: { name, email }, token }) => ({
	user: { name, email },
	token
});

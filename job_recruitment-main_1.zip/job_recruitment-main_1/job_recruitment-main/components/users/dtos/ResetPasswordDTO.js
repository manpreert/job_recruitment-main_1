module.exports = () => ({
	status: 'ok',
	message: 'An OTP has been sent to user email.',
	systemTime: Date.now(),
});

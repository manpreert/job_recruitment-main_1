module.exports = ({ token }) => ({
  status: 'success',
  token,
});

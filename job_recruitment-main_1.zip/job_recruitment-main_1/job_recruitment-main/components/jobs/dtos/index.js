const allJobsDTO = require('./allJobsDTO');
const createJobDTO = require('./createJobDTO');
const updateJobDTO = require('./updateJobDTO');
const deleteJobDTO = require('./deleteJobDTO');
const findOneJobDTO = require('./findOneJobDTO');
module.exports = {
	allJobsDTO,
	createJobDTO,
	updateJobDTO,
	deleteJobDTO,
	findOneJobDTO
};

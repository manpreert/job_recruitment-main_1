### Prerequisites for running the Project.

> You need to node.js version >= 14

> An active internet connection

### Steps to Run project.

#### 1. Run `npm install` [for first Time only]

#### 2. Run `npm run server`
